﻿namespace QQ聊天轰炸器
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.layeredPictureBox1 = new LayeredSkin.Controls.LayeredPictureBox();
            this.layeredPictureBox2 = new LayeredSkin.Controls.LayeredPictureBox();
            this.layeredLabel3 = new LayeredSkin.Controls.LayeredLabel();
            this.layeredButton2 = new LayeredSkin.Controls.LayeredButton();
            this.layeredButton1 = new LayeredSkin.Controls.LayeredButton();
            this.layeredBaseControl1 = new LayeredSkin.Controls.LayeredBaseControl();
            this.layeredCheckButton1 = new LayeredSkin.Controls.LayeredCheckButton();
            this.layeredButton3 = new LayeredSkin.Controls.LayeredButton();
            this.layeredTrackBar2 = new LayeredSkin.Controls.LayeredTrackBar();
            this.layeredLabel1 = new LayeredSkin.Controls.LayeredLabel();
            this.layeredLabel2 = new LayeredSkin.Controls.LayeredLabel();
            this.layeredLabel4 = new LayeredSkin.Controls.LayeredLabel();
            this.layeredTextBox1 = new LayeredSkin.Controls.LayeredTextBox();
            this.layeredLabel5 = new LayeredSkin.Controls.LayeredLabel();
            this.layeredLabel6 = new LayeredSkin.Controls.LayeredLabel();
            this.layeredPictureBox3 = new LayeredSkin.Controls.LayeredPictureBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.layeredCheckButton2 = new LayeredSkin.Controls.LayeredCheckButton();
            this.layeredButton5 = new LayeredSkin.Controls.LayeredButton();
            this.layeredLabel7 = new LayeredSkin.Controls.LayeredLabel();
            this.layeredLabel8 = new LayeredSkin.Controls.LayeredLabel();
            this.layeredLabel9 = new LayeredSkin.Controls.LayeredLabel();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // layeredPictureBox1
            // 
            this.layeredPictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredPictureBox1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredPictureBox1.Borders.BottomWidth = 1;
            this.layeredPictureBox1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredPictureBox1.Borders.LeftWidth = 1;
            this.layeredPictureBox1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredPictureBox1.Borders.RightWidth = 1;
            this.layeredPictureBox1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredPictureBox1.Borders.TopWidth = 1;
            this.layeredPictureBox1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredPictureBox1.Canvas")));
            this.layeredPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("layeredPictureBox1.Image")));
            this.layeredPictureBox1.Images = new System.Drawing.Image[] {
        ((System.Drawing.Image)(((System.Drawing.Image)(resources.GetObject("layeredPictureBox1.Images")))))};
            this.layeredPictureBox1.Interval = 100;
            this.layeredPictureBox1.Location = new System.Drawing.Point(10, -2);
            this.layeredPictureBox1.MultiImageAnimation = false;
            this.layeredPictureBox1.Name = "layeredPictureBox1";
            this.layeredPictureBox1.Size = new System.Drawing.Size(105, 53);
            this.layeredPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.layeredPictureBox1.TabIndex = 1;
            this.layeredPictureBox1.Text = "layeredPictureBox1";
            this.layeredPictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.layeredPictureBox1_MouseDown);
            // 
            // layeredPictureBox2
            // 
            this.layeredPictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredPictureBox2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredPictureBox2.Borders.BottomWidth = 1;
            this.layeredPictureBox2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredPictureBox2.Borders.LeftWidth = 1;
            this.layeredPictureBox2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredPictureBox2.Borders.RightWidth = 1;
            this.layeredPictureBox2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredPictureBox2.Borders.TopWidth = 1;
            this.layeredPictureBox2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredPictureBox2.Canvas")));
            this.layeredPictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("layeredPictureBox2.Image")));
            this.layeredPictureBox2.Images = new System.Drawing.Image[] {
        ((System.Drawing.Image)(((System.Drawing.Image)(resources.GetObject("layeredPictureBox2.Images")))))};
            this.layeredPictureBox2.Interval = 100;
            this.layeredPictureBox2.Location = new System.Drawing.Point(3, 24);
            this.layeredPictureBox2.MultiImageAnimation = false;
            this.layeredPictureBox2.Name = "layeredPictureBox2";
            this.layeredPictureBox2.Size = new System.Drawing.Size(338, 82);
            this.layeredPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.layeredPictureBox2.TabIndex = 2;
            this.layeredPictureBox2.Text = "layeredPictureBox2";
            this.layeredPictureBox2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.layeredPictureBox2_MouseDown);
            // 
            // layeredLabel3
            // 
            this.layeredLabel3.AutoSize = true;
            this.layeredLabel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredLabel3.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredLabel3.Borders.BottomWidth = 1;
            this.layeredLabel3.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredLabel3.Borders.LeftWidth = 1;
            this.layeredLabel3.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredLabel3.Borders.RightWidth = 1;
            this.layeredLabel3.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredLabel3.Borders.TopWidth = 1;
            this.layeredLabel3.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredLabel3.Canvas")));
            this.layeredLabel3.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredLabel3.ForeColor = System.Drawing.Color.White;
            this.layeredLabel3.HaloSize = 5;
            this.layeredLabel3.Location = new System.Drawing.Point(17, 74);
            this.layeredLabel3.Name = "layeredLabel3";
            this.layeredLabel3.Size = new System.Drawing.Size(79, 20);
            this.layeredLabel3.TabIndex = 7;
            this.layeredLabel3.Text = "QQ轰炸机";
            this.layeredLabel3.TextRenderMode = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredLabel3.TextShowMode = LayeredSkin.TextShowModes.Ordinary;
            // 
            // layeredButton2
            // 
            this.layeredButton2.AdaptImage = true;
            this.layeredButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton2.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.BottomWidth = 1;
            this.layeredButton2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.LeftWidth = 1;
            this.layeredButton2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.RightWidth = 1;
            this.layeredButton2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.TopWidth = 1;
            this.layeredButton2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton2.Canvas")));
            this.layeredButton2.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton2.HaloColor = System.Drawing.Color.White;
            this.layeredButton2.HaloSize = 5;
            this.layeredButton2.HoverImage = ((System.Drawing.Image)(resources.GetObject("layeredButton2.HoverImage")));
            this.layeredButton2.IsPureColor = false;
            this.layeredButton2.Location = new System.Drawing.Point(307, 75);
            this.layeredButton2.Name = "layeredButton2";
            this.layeredButton2.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton2.NormalImage")));
            this.layeredButton2.PressedImage = null;
            this.layeredButton2.Radius = 10;
            this.layeredButton2.ShowBorder = true;
            this.layeredButton2.Size = new System.Drawing.Size(20, 20);
            this.layeredButton2.TabIndex = 8;
            this.layeredButton2.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton2.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.layeredButton2.Click += new System.EventHandler(this.layeredButton2_Click);
            // 
            // layeredButton1
            // 
            this.layeredButton1.AdaptImage = true;
            this.layeredButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton1.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.BottomWidth = 1;
            this.layeredButton1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.LeftWidth = 1;
            this.layeredButton1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.RightWidth = 1;
            this.layeredButton1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.TopWidth = 1;
            this.layeredButton1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton1.Canvas")));
            this.layeredButton1.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton1.HaloColor = System.Drawing.Color.White;
            this.layeredButton1.HaloSize = 5;
            this.layeredButton1.HoverImage = ((System.Drawing.Image)(resources.GetObject("layeredButton1.HoverImage")));
            this.layeredButton1.IsPureColor = false;
            this.layeredButton1.Location = new System.Drawing.Point(279, 75);
            this.layeredButton1.Name = "layeredButton1";
            this.layeredButton1.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton1.NormalImage")));
            this.layeredButton1.PressedImage = null;
            this.layeredButton1.Radius = 10;
            this.layeredButton1.ShowBorder = true;
            this.layeredButton1.Size = new System.Drawing.Size(20, 20);
            this.layeredButton1.TabIndex = 9;
            this.layeredButton1.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton1.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.layeredButton1.Click += new System.EventHandler(this.layeredButton1_Click);
            // 
            // layeredBaseControl1
            // 
            this.layeredBaseControl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredBaseControl1.Borders.BottomColor = System.Drawing.Color.Transparent;
            this.layeredBaseControl1.Borders.BottomWidth = 1;
            this.layeredBaseControl1.Borders.LeftColor = System.Drawing.Color.NavajoWhite;
            this.layeredBaseControl1.Borders.LeftWidth = 2;
            this.layeredBaseControl1.Borders.RightColor = System.Drawing.Color.NavajoWhite;
            this.layeredBaseControl1.Borders.RightWidth = 3;
            this.layeredBaseControl1.Borders.TopColor = System.Drawing.Color.Transparent;
            this.layeredBaseControl1.Borders.TopWidth = 1;
            this.layeredBaseControl1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredBaseControl1.Canvas")));
            this.layeredBaseControl1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredBaseControl1.Location = new System.Drawing.Point(38, 131);
            this.layeredBaseControl1.Name = "layeredBaseControl1";
            this.layeredBaseControl1.Size = new System.Drawing.Size(270, 64);
            this.layeredBaseControl1.TabIndex = 10;
            this.layeredBaseControl1.Text = "layeredBaseControl1";
            // 
            // layeredCheckButton1
            // 
            this.layeredCheckButton1.AdaptImage = true;
            this.layeredCheckButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredCheckButton1.BaseColor = System.Drawing.Color.Wheat;
            this.layeredCheckButton1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredCheckButton1.Borders.BottomWidth = 1;
            this.layeredCheckButton1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredCheckButton1.Borders.LeftWidth = 1;
            this.layeredCheckButton1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredCheckButton1.Borders.RightWidth = 1;
            this.layeredCheckButton1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredCheckButton1.Borders.TopWidth = 1;
            this.layeredCheckButton1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredCheckButton1.Canvas")));
            this.layeredCheckButton1.Checked = true;
            this.layeredCheckButton1.CheckedHover = null;
            this.layeredCheckButton1.CheckedNormal = ((System.Drawing.Image)(resources.GetObject("layeredCheckButton1.CheckedNormal")));
            this.layeredCheckButton1.CheckedPressed = null;
            this.layeredCheckButton1.CheckOnClick = true;
            this.layeredCheckButton1.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredCheckButton1.HoverImage = null;
            this.layeredCheckButton1.IsPureColor = false;
            this.layeredCheckButton1.Location = new System.Drawing.Point(124, 166);
            this.layeredCheckButton1.Name = "layeredCheckButton1";
            this.layeredCheckButton1.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredCheckButton1.NormalImage")));
            this.layeredCheckButton1.PressedImage = null;
            this.layeredCheckButton1.Radius = 10;
            this.layeredCheckButton1.ShowBorder = true;
            this.layeredCheckButton1.Size = new System.Drawing.Size(91, 29);
            this.layeredCheckButton1.TabIndex = 22;
            this.layeredCheckButton1.UncheckedHover = null;
            this.layeredCheckButton1.UncheckedNormal = ((System.Drawing.Image)(resources.GetObject("layeredCheckButton1.UncheckedNormal")));
            this.layeredCheckButton1.UncheckedPressed = null;
            this.layeredCheckButton1.Click += new System.EventHandler(this.layeredCheckButton1_Click);
            // 
            // layeredButton3
            // 
            this.layeredButton3.AdaptImage = true;
            this.layeredButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton3.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton3.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.BottomWidth = 1;
            this.layeredButton3.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.LeftWidth = 1;
            this.layeredButton3.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.RightWidth = 1;
            this.layeredButton3.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.TopWidth = 1;
            this.layeredButton3.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton3.Canvas")));
            this.layeredButton3.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton3.HaloColor = System.Drawing.Color.White;
            this.layeredButton3.HaloSize = 5;
            this.layeredButton3.HoverImage = null;
            this.layeredButton3.IsPureColor = false;
            this.layeredButton3.Location = new System.Drawing.Point(69, 207);
            this.layeredButton3.Name = "layeredButton3";
            this.layeredButton3.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton3.NormalImage")));
            this.layeredButton3.PressedImage = ((System.Drawing.Image)(resources.GetObject("layeredButton3.PressedImage")));
            this.layeredButton3.Radius = 10;
            this.layeredButton3.ShowBorder = true;
            this.layeredButton3.Size = new System.Drawing.Size(24, 24);
            this.layeredButton3.TabIndex = 24;
            this.layeredButton3.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton3.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.layeredButton3.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.layeredButton3.Click += new System.EventHandler(this.layeredButton3_Click);
            // 
            // layeredTrackBar2
            // 
            this.layeredTrackBar2.AdaptImage = true;
            this.layeredTrackBar2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredTrackBar2.BackImage = null;
            this.layeredTrackBar2.BackLineColor = System.Drawing.Color.Black;
            this.layeredTrackBar2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredTrackBar2.Borders.BottomWidth = 1;
            this.layeredTrackBar2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredTrackBar2.Borders.LeftWidth = 1;
            this.layeredTrackBar2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredTrackBar2.Borders.RightWidth = 1;
            this.layeredTrackBar2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredTrackBar2.Borders.TopWidth = 1;
            this.layeredTrackBar2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredTrackBar2.Canvas")));
            this.layeredTrackBar2.ControlRectangle = new System.Drawing.Rectangle(5, 5, 167, 28);
            this.layeredTrackBar2.LineWidth = 2;
            this.layeredTrackBar2.Location = new System.Drawing.Point(81, 251);
            this.layeredTrackBar2.MouseCanControl = true;
            this.layeredTrackBar2.Name = "layeredTrackBar2";
            this.layeredTrackBar2.Orientation = LayeredSkin.Controls.Orientations.Horizontal;
            this.layeredTrackBar2.PointImage = ((System.Drawing.Image)(resources.GetObject("layeredTrackBar2.PointImage")));
            this.layeredTrackBar2.PointImageHover = ((System.Drawing.Image)(resources.GetObject("layeredTrackBar2.PointImageHover")));
            this.layeredTrackBar2.PointImagePressed = ((System.Drawing.Image)(resources.GetObject("layeredTrackBar2.PointImagePressed")));
            this.layeredTrackBar2.PointState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredTrackBar2.Size = new System.Drawing.Size(177, 38);
            this.layeredTrackBar2.SurfaceImage = null;
            this.layeredTrackBar2.SurfaceLineColor = System.Drawing.Color.White;
            this.layeredTrackBar2.TabIndex = 28;
            this.layeredTrackBar2.Text = "layeredTrackBar2";
            this.layeredTrackBar2.Value = 0.1D;
            this.layeredTrackBar2.Click += new System.EventHandler(this.layeredTrackBar2_Click);
            // 
            // layeredLabel1
            // 
            this.layeredLabel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredLabel1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredLabel1.Borders.BottomWidth = 1;
            this.layeredLabel1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredLabel1.Borders.LeftWidth = 1;
            this.layeredLabel1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredLabel1.Borders.RightWidth = 1;
            this.layeredLabel1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredLabel1.Borders.TopWidth = 1;
            this.layeredLabel1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredLabel1.Canvas")));
            this.layeredLabel1.Font = new System.Drawing.Font("新宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredLabel1.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.layeredLabel1.HaloColor = System.Drawing.Color.Transparent;
            this.layeredLabel1.HaloSize = 5;
            this.layeredLabel1.Location = new System.Drawing.Point(38, 107);
            this.layeredLabel1.Name = "layeredLabel1";
            this.layeredLabel1.Size = new System.Drawing.Size(98, 22);
            this.layeredLabel1.TabIndex = 31;
            this.layeredLabel1.Text = "请输入内容：";
            // 
            // layeredLabel2
            // 
            this.layeredLabel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredLabel2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredLabel2.Borders.BottomWidth = 1;
            this.layeredLabel2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredLabel2.Borders.LeftWidth = 1;
            this.layeredLabel2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredLabel2.Borders.RightWidth = 1;
            this.layeredLabel2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredLabel2.Borders.TopWidth = 1;
            this.layeredLabel2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredLabel2.Canvas")));
            this.layeredLabel2.Font = new System.Drawing.Font("新宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredLabel2.ForeColor = System.Drawing.Color.Gray;
            this.layeredLabel2.HaloColor = System.Drawing.Color.Transparent;
            this.layeredLabel2.HaloSize = 5;
            this.layeredLabel2.Location = new System.Drawing.Point(238, 239);
            this.layeredLabel2.Name = "layeredLabel2";
            this.layeredLabel2.Size = new System.Drawing.Size(56, 22);
            this.layeredLabel2.TabIndex = 32;
            this.layeredLabel2.Text = "骂人模式";
            // 
            // layeredLabel4
            // 
            this.layeredLabel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredLabel4.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredLabel4.Borders.BottomWidth = 1;
            this.layeredLabel4.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredLabel4.Borders.LeftWidth = 1;
            this.layeredLabel4.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredLabel4.Borders.RightWidth = 1;
            this.layeredLabel4.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredLabel4.Borders.TopWidth = 1;
            this.layeredLabel4.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredLabel4.Canvas")));
            this.layeredLabel4.Font = new System.Drawing.Font("新宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredLabel4.ForeColor = System.Drawing.Color.Gray;
            this.layeredLabel4.HaloColor = System.Drawing.Color.Transparent;
            this.layeredLabel4.HaloSize = 5;
            this.layeredLabel4.Location = new System.Drawing.Point(54, 238);
            this.layeredLabel4.Name = "layeredLabel4";
            this.layeredLabel4.Size = new System.Drawing.Size(64, 25);
            this.layeredLabel4.TabIndex = 33;
            this.layeredLabel4.Text = "添加表情";
            // 
            // layeredTextBox1
            // 
            this.layeredTextBox1.BackColor = System.Drawing.Color.Bisque;
            this.layeredTextBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredTextBox1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredTextBox1.Borders.BottomWidth = 1;
            this.layeredTextBox1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredTextBox1.Borders.LeftWidth = 1;
            this.layeredTextBox1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredTextBox1.Borders.RightWidth = 1;
            this.layeredTextBox1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredTextBox1.Borders.TopWidth = 1;
            this.layeredTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.layeredTextBox1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredTextBox1.Canvas")));
            this.layeredTextBox1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredTextBox1.ForeColor = System.Drawing.Color.Black;
            this.layeredTextBox1.Location = new System.Drawing.Point(56, 130);
            this.layeredTextBox1.Multiline = true;
            this.layeredTextBox1.Name = "layeredTextBox1";
            this.layeredTextBox1.Size = new System.Drawing.Size(234, 34);
            this.layeredTextBox1.TabIndex = 34;
            this.layeredTextBox1.Text = "QQ聊天轰炸机，骚扰攻击之必备佳品。";
            this.layeredTextBox1.TransparencyKey = System.Drawing.Color.Bisque;
            this.layeredTextBox1.WaterColor = System.Drawing.Color.Black;
            this.layeredTextBox1.WaterFont = new System.Drawing.Font("新宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredTextBox1.WaterText = "";
            this.layeredTextBox1.WaterTextOffset = new System.Drawing.Point(4, 4);
            // 
            // layeredLabel5
            // 
            this.layeredLabel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredLabel5.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredLabel5.Borders.BottomWidth = 1;
            this.layeredLabel5.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredLabel5.Borders.LeftWidth = 1;
            this.layeredLabel5.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredLabel5.Borders.RightWidth = 1;
            this.layeredLabel5.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredLabel5.Borders.TopWidth = 1;
            this.layeredLabel5.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredLabel5.Canvas")));
            this.layeredLabel5.Font = new System.Drawing.Font("新宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredLabel5.ForeColor = System.Drawing.Color.Gray;
            this.layeredLabel5.HaloColor = System.Drawing.Color.Transparent;
            this.layeredLabel5.HaloSize = 5;
            this.layeredLabel5.Location = new System.Drawing.Point(40, 263);
            this.layeredLabel5.Name = "layeredLabel5";
            this.layeredLabel5.Size = new System.Drawing.Size(43, 25);
            this.layeredLabel5.TabIndex = 35;
            this.layeredLabel5.Text = "速率：";
            // 
            // layeredLabel6
            // 
            this.layeredLabel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredLabel6.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredLabel6.Borders.BottomWidth = 1;
            this.layeredLabel6.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredLabel6.Borders.LeftWidth = 1;
            this.layeredLabel6.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredLabel6.Borders.RightWidth = 1;
            this.layeredLabel6.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredLabel6.Borders.TopWidth = 1;
            this.layeredLabel6.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredLabel6.Canvas")));
            this.layeredLabel6.Font = new System.Drawing.Font("新宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredLabel6.ForeColor = System.Drawing.Color.Gray;
            this.layeredLabel6.HaloColor = System.Drawing.Color.Transparent;
            this.layeredLabel6.HaloSize = 5;
            this.layeredLabel6.Location = new System.Drawing.Point(259, 263);
            this.layeredLabel6.Name = "layeredLabel6";
            this.layeredLabel6.Size = new System.Drawing.Size(62, 25);
            this.layeredLabel6.TabIndex = 36;
            this.layeredLabel6.Text = "0.1秒/条";
            // 
            // layeredPictureBox3
            // 
            this.layeredPictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredPictureBox3.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredPictureBox3.Borders.BottomWidth = 1;
            this.layeredPictureBox3.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredPictureBox3.Borders.LeftWidth = 1;
            this.layeredPictureBox3.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredPictureBox3.Borders.RightWidth = 1;
            this.layeredPictureBox3.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredPictureBox3.Borders.TopWidth = 1;
            this.layeredPictureBox3.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredPictureBox3.Canvas")));
            this.layeredPictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("layeredPictureBox3.Image")));
            this.layeredPictureBox3.Images = new System.Drawing.Image[] {
        ((System.Drawing.Image)(((System.Drawing.Image)(resources.GetObject("layeredPictureBox3.Images")))))};
            this.layeredPictureBox3.Interval = 100;
            this.layeredPictureBox3.Location = new System.Drawing.Point(69, -4);
            this.layeredPictureBox3.MultiImageAnimation = false;
            this.layeredPictureBox3.Name = "layeredPictureBox3";
            this.layeredPictureBox3.Size = new System.Drawing.Size(190, 50);
            this.layeredPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.layeredPictureBox3.TabIndex = 37;
            this.layeredPictureBox3.Text = "layeredPictureBox3";
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // layeredCheckButton2
            // 
            this.layeredCheckButton2.AdaptImage = true;
            this.layeredCheckButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredCheckButton2.BaseColor = System.Drawing.Color.Wheat;
            this.layeredCheckButton2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredCheckButton2.Borders.BottomWidth = 1;
            this.layeredCheckButton2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredCheckButton2.Borders.LeftWidth = 1;
            this.layeredCheckButton2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredCheckButton2.Borders.RightWidth = 1;
            this.layeredCheckButton2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredCheckButton2.Borders.TopWidth = 1;
            this.layeredCheckButton2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredCheckButton2.Canvas")));
            this.layeredCheckButton2.Checked = false;
            this.layeredCheckButton2.CheckedHover = null;
            this.layeredCheckButton2.CheckedNormal = ((System.Drawing.Image)(resources.GetObject("layeredCheckButton2.CheckedNormal")));
            this.layeredCheckButton2.CheckedPressed = null;
            this.layeredCheckButton2.CheckOnClick = true;
            this.layeredCheckButton2.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredCheckButton2.HoverImage = null;
            this.layeredCheckButton2.IsPureColor = false;
            this.layeredCheckButton2.Location = new System.Drawing.Point(247, 202);
            this.layeredCheckButton2.Name = "layeredCheckButton2";
            this.layeredCheckButton2.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredCheckButton2.NormalImage")));
            this.layeredCheckButton2.PressedImage = null;
            this.layeredCheckButton2.Radius = 10;
            this.layeredCheckButton2.ShowBorder = true;
            this.layeredCheckButton2.Size = new System.Drawing.Size(35, 31);
            this.layeredCheckButton2.TabIndex = 38;
            this.layeredCheckButton2.UncheckedHover = null;
            this.layeredCheckButton2.UncheckedNormal = ((System.Drawing.Image)(resources.GetObject("layeredCheckButton2.UncheckedNormal")));
            this.layeredCheckButton2.UncheckedPressed = null;
            // 
            // layeredButton5
            // 
            this.layeredButton5.AdaptImage = true;
            this.layeredButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton5.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton5.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton5.Borders.BottomWidth = 1;
            this.layeredButton5.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton5.Borders.LeftWidth = 1;
            this.layeredButton5.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton5.Borders.RightWidth = 1;
            this.layeredButton5.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton5.Borders.TopWidth = 1;
            this.layeredButton5.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton5.Canvas")));
            this.layeredButton5.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton5.HaloColor = System.Drawing.Color.White;
            this.layeredButton5.HaloSize = 5;
            this.layeredButton5.HoverImage = null;
            this.layeredButton5.IsPureColor = false;
            this.layeredButton5.Location = new System.Drawing.Point(134, 201);
            this.layeredButton5.Name = "layeredButton5";
            this.layeredButton5.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton5.NormalImage")));
            this.layeredButton5.PressedImage = ((System.Drawing.Image)(resources.GetObject("layeredButton5.PressedImage")));
            this.layeredButton5.Radius = 10;
            this.layeredButton5.ShowBorder = true;
            this.layeredButton5.Size = new System.Drawing.Size(70, 38);
            this.layeredButton5.TabIndex = 39;
            this.layeredButton5.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton5.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.layeredButton5.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.layeredButton5.Click += new System.EventHandler(this.layeredButton5_Click);
            // 
            // layeredLabel7
            // 
            this.layeredLabel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredLabel7.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredLabel7.Borders.BottomWidth = 1;
            this.layeredLabel7.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredLabel7.Borders.LeftWidth = 1;
            this.layeredLabel7.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredLabel7.Borders.RightWidth = 1;
            this.layeredLabel7.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredLabel7.Borders.TopWidth = 1;
            this.layeredLabel7.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredLabel7.Canvas")));
            this.layeredLabel7.Font = new System.Drawing.Font("新宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredLabel7.ForeColor = System.Drawing.Color.Gray;
            this.layeredLabel7.HaloColor = System.Drawing.Color.Transparent;
            this.layeredLabel7.HaloSize = 5;
            this.layeredLabel7.Location = new System.Drawing.Point(143, 240);
            this.layeredLabel7.Name = "layeredLabel7";
            this.layeredLabel7.Size = new System.Drawing.Size(64, 25);
            this.layeredLabel7.TabIndex = 40;
            this.layeredLabel7.Text = "强行聊天";
            // 
            // layeredLabel8
            // 
            this.layeredLabel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredLabel8.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredLabel8.Borders.BottomWidth = 1;
            this.layeredLabel8.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredLabel8.Borders.LeftWidth = 1;
            this.layeredLabel8.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredLabel8.Borders.RightWidth = 1;
            this.layeredLabel8.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredLabel8.Borders.TopWidth = 1;
            this.layeredLabel8.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredLabel8.Canvas")));
            this.layeredLabel8.Font = new System.Drawing.Font("新宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredLabel8.ForeColor = System.Drawing.Color.Gray;
            this.layeredLabel8.HaloColor = System.Drawing.Color.Transparent;
            this.layeredLabel8.HaloSize = 5;
            this.layeredLabel8.Location = new System.Drawing.Point(223, 175);
            this.layeredLabel8.Name = "layeredLabel8";
            this.layeredLabel8.Size = new System.Drawing.Size(56, 22);
            this.layeredLabel8.TabIndex = 41;
            this.layeredLabel8.Text = "暂停";
            // 
            // layeredLabel9
            // 
            this.layeredLabel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredLabel9.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredLabel9.Borders.BottomWidth = 1;
            this.layeredLabel9.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredLabel9.Borders.LeftWidth = 1;
            this.layeredLabel9.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredLabel9.Borders.RightWidth = 1;
            this.layeredLabel9.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredLabel9.Borders.TopWidth = 1;
            this.layeredLabel9.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredLabel9.Canvas")));
            this.layeredLabel9.Font = new System.Drawing.Font("新宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredLabel9.ForeColor = System.Drawing.Color.Gray;
            this.layeredLabel9.HaloColor = System.Drawing.Color.Transparent;
            this.layeredLabel9.HaloSize = 5;
            this.layeredLabel9.Location = new System.Drawing.Point(85, 175);
            this.layeredLabel9.Name = "layeredLabel9";
            this.layeredLabel9.Size = new System.Drawing.Size(27, 22);
            this.layeredLabel9.TabIndex = 42;
            this.layeredLabel9.Text = "轰炸";
            // 
            // Form1
            // 
            this.AnimationType = LayeredSkin.Forms.AnimationTypes.GradualCurtainEffect;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.CaptionShowMode = LayeredSkin.TextShowModes.None;
            this.ClientSize = new System.Drawing.Size(345, 344);
            this.Controls.Add(this.layeredLabel9);
            this.Controls.Add(this.layeredLabel8);
            this.Controls.Add(this.layeredLabel7);
            this.Controls.Add(this.layeredButton5);
            this.Controls.Add(this.layeredCheckButton2);
            this.Controls.Add(this.layeredPictureBox3);
            this.Controls.Add(this.layeredLabel6);
            this.Controls.Add(this.layeredLabel5);
            this.Controls.Add(this.layeredTextBox1);
            this.Controls.Add(this.layeredLabel4);
            this.Controls.Add(this.layeredLabel2);
            this.Controls.Add(this.layeredLabel1);
            this.Controls.Add(this.layeredTrackBar2);
            this.Controls.Add(this.layeredButton3);
            this.Controls.Add(this.layeredCheckButton1);
            this.Controls.Add(this.layeredBaseControl1);
            this.Controls.Add(this.layeredButton1);
            this.Controls.Add(this.layeredButton2);
            this.Controls.Add(this.layeredLabel3);
            this.Controls.Add(this.layeredPictureBox2);
            this.Controls.Add(this.layeredPictureBox1);
            this.DrawIcon = false;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QQ聊天轰炸机";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private LayeredSkin.Controls.LayeredPictureBox layeredPictureBox1;
        private LayeredSkin.Controls.LayeredPictureBox layeredPictureBox2;
        private LayeredSkin.Controls.LayeredLabel layeredLabel3;
        private LayeredSkin.Controls.LayeredButton layeredButton2;
        private LayeredSkin.Controls.LayeredButton layeredButton1;
        private LayeredSkin.Controls.LayeredBaseControl layeredBaseControl1;
        private LayeredSkin.Controls.LayeredCheckButton layeredCheckButton1;
        private LayeredSkin.Controls.LayeredButton layeredButton3;
        private LayeredSkin.Controls.LayeredTrackBar layeredTrackBar2;
        private LayeredSkin.Controls.LayeredLabel layeredLabel1;
        private LayeredSkin.Controls.LayeredLabel layeredLabel2;
        private LayeredSkin.Controls.LayeredLabel layeredLabel4;
        private LayeredSkin.Controls.LayeredTextBox layeredTextBox1;
        private LayeredSkin.Controls.LayeredLabel layeredLabel5;
        private LayeredSkin.Controls.LayeredLabel layeredLabel6;
        private LayeredSkin.Controls.LayeredPictureBox layeredPictureBox3;
        private System.Windows.Forms.Timer timer2;
        private LayeredSkin.Controls.LayeredCheckButton layeredCheckButton2;
        private LayeredSkin.Controls.LayeredButton layeredButton5;
        private LayeredSkin.Controls.LayeredLabel layeredLabel7;
        private LayeredSkin.Controls.LayeredLabel layeredLabel8;
        private LayeredSkin.Controls.LayeredLabel layeredLabel9;
    }
}

