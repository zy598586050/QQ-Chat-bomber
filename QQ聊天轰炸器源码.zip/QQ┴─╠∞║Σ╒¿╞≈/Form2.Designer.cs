﻿namespace QQ聊天轰炸器
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.layeredButton3 = new LayeredSkin.Controls.LayeredButton();
            this.layeredButton1 = new LayeredSkin.Controls.LayeredButton();
            this.layeredTextBox1 = new LayeredSkin.Controls.LayeredTextBox();
            this.layeredButton2 = new LayeredSkin.Controls.LayeredButton();
            this.SuspendLayout();
            // 
            // layeredButton3
            // 
            this.layeredButton3.AdaptImage = true;
            this.layeredButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.layeredButton3.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.BottomWidth = 1;
            this.layeredButton3.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.LeftWidth = 1;
            this.layeredButton3.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.RightWidth = 1;
            this.layeredButton3.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.TopWidth = 1;
            this.layeredButton3.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton3.Canvas")));
            this.layeredButton3.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton3.HaloColor = System.Drawing.Color.White;
            this.layeredButton3.HaloSize = 5;
            this.layeredButton3.HoverImage = null;
            this.layeredButton3.IsPureColor = false;
            this.layeredButton3.Location = new System.Drawing.Point(176, 98);
            this.layeredButton3.Name = "layeredButton3";
            this.layeredButton3.NormalImage = null;
            this.layeredButton3.PressedImage = null;
            this.layeredButton3.Radius = 10;
            this.layeredButton3.ShowBorder = true;
            this.layeredButton3.Size = new System.Drawing.Size(32, 26);
            this.layeredButton3.TabIndex = 37;
            this.layeredButton3.Text = "加";
            this.layeredButton3.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton3.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.layeredButton3.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.layeredButton3.Click += new System.EventHandler(this.layeredButton3_Click);
            // 
            // layeredButton1
            // 
            this.layeredButton1.AdaptImage = true;
            this.layeredButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.layeredButton1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.BottomWidth = 1;
            this.layeredButton1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.LeftWidth = 1;
            this.layeredButton1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.RightWidth = 1;
            this.layeredButton1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.TopWidth = 1;
            this.layeredButton1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton1.Canvas")));
            this.layeredButton1.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredButton1.HaloColor = System.Drawing.Color.White;
            this.layeredButton1.HaloSize = 5;
            this.layeredButton1.HoverImage = null;
            this.layeredButton1.IsPureColor = false;
            this.layeredButton1.Location = new System.Drawing.Point(124, 98);
            this.layeredButton1.Name = "layeredButton1";
            this.layeredButton1.NormalImage = null;
            this.layeredButton1.PressedImage = null;
            this.layeredButton1.Radius = 10;
            this.layeredButton1.ShowBorder = true;
            this.layeredButton1.Size = new System.Drawing.Size(32, 26);
            this.layeredButton1.TabIndex = 38;
            this.layeredButton1.Text = "聊";
            this.layeredButton1.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.layeredButton1.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.layeredButton1.Click += new System.EventHandler(this.layeredButton1_Click);
            // 
            // layeredTextBox1
            // 
            this.layeredTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.layeredTextBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredTextBox1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredTextBox1.Borders.BottomWidth = 1;
            this.layeredTextBox1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredTextBox1.Borders.LeftWidth = 1;
            this.layeredTextBox1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredTextBox1.Borders.RightWidth = 1;
            this.layeredTextBox1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredTextBox1.Borders.TopWidth = 1;
            this.layeredTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.layeredTextBox1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredTextBox1.Canvas")));
            this.layeredTextBox1.Font = new System.Drawing.Font("楷体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredTextBox1.ForeColor = System.Drawing.Color.Red;
            this.layeredTextBox1.Location = new System.Drawing.Point(125, 68);
            this.layeredTextBox1.Multiline = true;
            this.layeredTextBox1.Name = "layeredTextBox1";
            this.layeredTextBox1.Size = new System.Drawing.Size(141, 27);
            this.layeredTextBox1.TabIndex = 39;
            this.layeredTextBox1.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.layeredTextBox1.WaterColor = System.Drawing.Color.Red;
            this.layeredTextBox1.WaterFont = new System.Drawing.Font("楷体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredTextBox1.WaterText = "请输入对方QQ号：";
            this.layeredTextBox1.WaterTextOffset = new System.Drawing.Point(4, 4);
            // 
            // layeredButton2
            // 
            this.layeredButton2.AdaptImage = true;
            this.layeredButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton2.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.BottomWidth = 1;
            this.layeredButton2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.LeftWidth = 1;
            this.layeredButton2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.RightWidth = 1;
            this.layeredButton2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.TopWidth = 1;
            this.layeredButton2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton2.Canvas")));
            this.layeredButton2.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton2.HaloColor = System.Drawing.Color.White;
            this.layeredButton2.HaloSize = 5;
            this.layeredButton2.HoverImage = ((System.Drawing.Image)(resources.GetObject("layeredButton2.HoverImage")));
            this.layeredButton2.IsPureColor = false;
            this.layeredButton2.Location = new System.Drawing.Point(232, 40);
            this.layeredButton2.Name = "layeredButton2";
            this.layeredButton2.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton2.NormalImage")));
            this.layeredButton2.PressedImage = null;
            this.layeredButton2.Radius = 10;
            this.layeredButton2.ShowBorder = true;
            this.layeredButton2.Size = new System.Drawing.Size(20, 20);
            this.layeredButton2.TabIndex = 40;
            this.layeredButton2.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton2.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.layeredButton2.Click += new System.EventHandler(this.layeredButton2_Click_1);
            // 
            // Form2
            // 
            this.AnimationType = LayeredSkin.Forms.AnimationTypes.ZoomEffect;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.CaptionShowMode = LayeredSkin.TextShowModes.None;
            this.ClientSize = new System.Drawing.Size(307, 203);
            this.Controls.Add(this.layeredButton2);
            this.Controls.Add(this.layeredTextBox1);
            this.Controls.Add(this.layeredButton1);
            this.Controls.Add(this.layeredButton3);
            this.DrawIcon = false;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "强聊强加";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private LayeredSkin.Controls.LayeredButton layeredButton3;
        private LayeredSkin.Controls.LayeredButton layeredButton1;
        private LayeredSkin.Controls.LayeredTextBox layeredTextBox1;
        private LayeredSkin.Controls.LayeredButton layeredButton2;
    }
}